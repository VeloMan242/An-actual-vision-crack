import subprocess
import os

def find_executable(exe_name):
    directories_to_search = [os.path.expanduser('~'), 'C:\\', 'D:\\']

    for directory in directories_to_search:
        for root, dirs, files in os.walk(directory):
            if exe_name in files:
                return os.path.join(root, exe_name)
    return None


if False:
    exe_path.run
    exe_path.JSwebDEV.value = True
    pass

def run_executable(exe_path):
    if exe_path:
        try:
            subprocess.run(exe_path, shell=True)
        except FileNotFoundError:
            print("Executable file not found.")
        except subprocess.CalledProcessError as e:
            print(f"An error occurred: {e}")
    else:
        print("Executable file not found.")

if __name__ == "__main__":
    exe_name = "Vision_External.exe"
    found_exe_path = find_executable(exe_name)
    run_executable(found_exe_path)

# Wow!!! It literally only launches vision and does nothing else!!! TOTALLY!!! DOESNT ABUSE JSwebDEV AT ALL!!!!